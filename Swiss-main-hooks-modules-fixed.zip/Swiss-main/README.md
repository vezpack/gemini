
# Swiss

**Swiss is a native utility client for MCBE.**

---

<p align="center">
  <img src="https://readme-typing-svg.demolab.com?font=Fira+Code&pause=1000&center=true&vCenter=true&width=435&lines=Swiss;Native+utility+client+for+MCBE" alt="Swiss" />
</p>

https://github.com/user-attachments/assets/78a0e0c0-1d32-4cc3-b2ea-2ac1f9c3727a
